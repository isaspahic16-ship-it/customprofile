(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const fine = matchMedia('(pointer: fine)').matches;
const data = JSON.parse($('#data').textContent);

/* ---------- loader ---------- */
let pct = 0;
const ldp = $('#ldp');
const tick = setInterval(() => {
  pct = Math.min(100, pct + 4 + Math.random() * 9);
  ldp.textContent = Math.floor(pct);
  if (pct >= 100) {
    clearInterval(tick);
    setTimeout(() => { $('#loader').classList.add('done'); document.body.classList.add('ready'); countUp(); }, 250);
  }
}, 70);

/* ---------- count-up numbers (runs when visible) ---------- */
const fmt = (n, d) => n.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
function animate(el) {
  if (el.dataset.done) return;
  el.dataset.done = 1;
  const to = parseFloat(el.dataset.count), d = +(el.dataset.dec || 0), suf = el.dataset.suffix || '';
  if (reduce) { el.textContent = fmt(to, d) + suf; return; }
  const t0 = performance.now(), dur = 1400;
  (function step(t) {
    const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 4);
    el.textContent = fmt(to * e, d) + suf;
    if (k < 1) requestAnimationFrame(step);
  })(t0);
}
function countUp() {
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { animate(e.target); io.unobserve(e.target); } }), { threshold: .5 });
  $$('[data-count]').forEach(el => io.observe(el));
}

/* ---------- cursor, glow, tilt ---------- */
const glow = $('#glow'), cur = $('#cur'), dot = $('#cur-dot'), card = $('#card');
let mx = innerWidth / 2, my = innerHeight / 2, gx = mx, gy = my, cx = mx, cy = my;
addEventListener('pointermove', e => { mx = e.clientX; my = e.clientY; dot.style.transform = `translate(${mx}px,${my}px)`; }, { passive: true });
document.addEventListener('pointerover', e => cur.classList.toggle('hov', !!e.target.closest('a,button,.bar,input')));
addEventListener('pointerdown', e => {
  const r = document.createElement('i'); r.className = 'ripple';
  r.style.left = e.clientX + 'px'; r.style.top = e.clientY + 'px';
  document.body.appendChild(r); setTimeout(() => r.remove(), 650);
});
let tiltX = 0, tiltY = 0, tx = 0, ty = 0;
card.addEventListener('pointermove', e => {
  const b = card.getBoundingClientRect();
  const px = (e.clientX - b.left) / b.width, py = (e.clientY - b.top) / b.height;
  tx = (py - .5) * -8; ty = (px - .5) * 10;
  card.style.setProperty('--mx', px * 100 + '%'); card.style.setProperty('--my', py * 100 + '%');
});
card.addEventListener('pointerleave', () => { tx = 0; ty = 0; });
(function loop() {
  gx += (mx - gx) * .08; gy += (my - gy) * .08; cx += (mx - cx) * .22; cy += (my - cy) * .22;
  glow.style.transform = `translate(${gx}px,${gy}px) translate(-50%,-50%)`;
  if (fine) cur.style.transform = `translate(${cx}px,${cy}px)`;
  if (fine && !reduce) {
    tiltX += (tx - tiltX) * .1; tiltY += (ty - tiltY) * .1;
    if (document.body.classList.contains('ready') && card.getAnimations().every(a => a.playState === 'finished' || !a.effect))
      card.style.transform = `rotateX(${tiltX}deg) rotateY(${tiltY}deg)`;
  }
  requestAnimationFrame(loop);
})();

/* ---------- occasional glitch ---------- */
const nm = $('.name');
if (!reduce) setInterval(() => { nm.classList.add('glitch'); setTimeout(() => nm.classList.remove('glitch'), 160); }, 6500);

/* ---------- nav highlight ---------- */
const links = $$('.nav a');
links.forEach(a => a.addEventListener('click', () => links.forEach(x => x.classList.toggle('active', x === a))));
addEventListener('load', () => { document.fonts.load('400 1em "Font Awesome 6 Brands"').then(f => { if (!f.length) document.documentElement.classList.add('no-fa'); }).catch(() => document.documentElement.classList.add('no-fa')); });
const so = new IntersectionObserver(es => es.forEach(e => {
  if (e.isIntersecting) links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + e.target.id));
}), { rootMargin: '-45% 0px -50% 0px' });
['home', 'projects'].forEach(id => { const el = document.getElementById(id); if (el) so.observe(el); });

/* ---------- background canvas: particles, stars, parallax (pauses when hidden) ---------- */
(function bg() {
  const c = $('#bg'), g = c.getContext('2d');
  let w, h, dpr, P = [], S = [], run = true;
  const init = () => {
    dpr = Math.min(devicePixelRatio || 1, 1.5); w = c.width = innerWidth * dpr; h = c.height = innerHeight * dpr;
    const n = innerWidth < 700 ? 40 : 90;
    P = Array.from({ length: n }, () => ({ x: Math.random() * w, y: Math.random() * h, r: (Math.random() * 1.6 + .4) * dpr, v: Math.random() * .25 + .08, a: Math.random() * .5 + .15 }));
    S = Array.from({ length: 70 }, () => ({ x: Math.random() * w, y: Math.random() * h, r: Math.random() * dpr, p: Math.random() * 6 }));
  };
  init(); addEventListener('resize', init);
  document.addEventListener('visibilitychange', () => { run = !document.hidden; if (run) draw(0); });
  function draw(t) {
    if (!run) return;
    g.clearRect(0, 0, w, h);
    const ox = (mx / innerWidth - .5) * -20 * dpr, oy = (my / innerHeight - .5) * -20 * dpr;
    g.fillStyle = '#fff';
    for (const s of S) { g.globalAlpha = .15 + .25 * Math.sin(t / 1200 + s.p); g.fillRect(s.x + ox * .3, s.y + oy * .3, s.r + .6, s.r + .6); }
    for (const p of P) {
      p.y -= p.v * dpr; if (p.y < -5) { p.y = h + 5; p.x = Math.random() * w; }
      g.globalAlpha = p.a; g.fillStyle = '#ff3b55';
      g.beginPath(); g.arc(p.x + ox, p.y + oy, p.r, 0, 6.283); g.fill();
    }
    requestAnimationFrame(draw);
  }
  requestAnimationFrame(draw);
})();

/* ---------- music player ---------- */
(function music() {
  const player = $('#player'), playBtn = $('#play'), prog = $('#prog'), bar = $('#bar'), time = $('#time'), vol = $('#vol'), viz = $('#viz'), vg = viz.getContext('2d');
  const src = document.body.dataset.audio;
  let ac, an, gain, audio, playing = false, synthT = 0, last = 0, lastT = 0;
  const DUR = 180, buf = new Uint8Array(32);

  function setup() {
    if (ac) return;
    ac = new (window.AudioContext || window.webkitAudioContext)();
    an = ac.createAnalyser(); an.fftSize = 64;
    gain = ac.createGain(); gain.gain.value = vol.value / 100;
    an.connect(gain); gain.connect(ac.destination);
    if (src) {
      audio = new Audio(src); audio.loop = true; audio.crossOrigin = 'anonymous';
      ac.createMediaElementSource(audio).connect(an);
    } else { // no mp3 provided: generate a dark ambient pad so the player works out of the box
      [55, 82.41, 110, 164.81].forEach((f, i) => {
        const o = ac.createOscillator(), l = ac.createOscillator(), lg = ac.createGain(), og = ac.createGain();
        o.type = i % 2 ? 'sawtooth' : 'sine'; o.frequency.value = f; o.detune.value = i * 3;
        l.frequency.value = .08 + i * .05; lg.gain.value = .02; og.gain.value = .05;
        l.connect(lg); lg.connect(og.gain); o.connect(og); og.connect(an); o.start(); l.start();
      });
    }
  }
  async function toggle() {
    setup();
    if (!playing) { await ac.resume(); if (audio) audio.play(); playing = true; lastT = performance.now(); }
    else { if (audio) audio.pause(); await ac.suspend(); playing = false; }
    player.classList.toggle('on', playing);
    playBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="${playing ? 'M6 5h4v14H6zm8 0h4v14h-4z' : 'M8 5v14l11-7z'}"/></svg>`;
  }
  const mmss = s => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
  function frame(t) {
    let cur = synthT, dur = DUR;
    if (audio && audio.duration) { cur = audio.currentTime; dur = audio.duration; }
    else if (playing) { synthT = (synthT + (t - lastT) / 1000) % DUR; cur = synthT; }
    lastT = t;
    prog.style.width = (cur / dur * 100) + '%'; time.textContent = mmss(cur);
    vg.clearRect(0, 0, 64, 28);
    if (an) an.getByteFrequencyData(buf);
    for (let i = 0; i < 8; i++) {
      const v = playing && an ? buf[i * 2 + 1] / 255 : .12 + .05 * Math.sin(t / 500 + i);
      const bh = Math.max(2, v * 28);
      vg.fillStyle = '#ff3b55'; vg.fillRect(i * 8, 28 - bh, 5, bh);
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  playBtn.addEventListener('click', toggle);
  vol.addEventListener('input', () => { if (gain) gain.gain.value = vol.value / 100; });
  bar.addEventListener('click', e => {
    const k = (e.clientX - bar.getBoundingClientRect().left) / bar.clientWidth;
    if (audio && audio.duration) audio.currentTime = k * audio.duration; else synthT = k * DUR;
  });
  window.__music = { toggle, isPlaying: () => playing };
})();

/* ---------- command panel (Ctrl+K) ---------- */
(function cmd() {
  const box = $('#cmd'), out = $('#out'), inp = $('#cin');
  const print = (t, html) => { const d = document.createElement('div'); html ? d.innerHTML = t : d.textContent = t; out.appendChild(d); out.scrollTop = out.scrollHeight; };
  const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const cmds = {
    help: () => print('Commands: help, about, socials, music, projects, clear'),
    about: () => print(`${data.name}: ${data.bio}`),
    socials: () => data.socials.forEach(s => print(`${esc(s.label)}: <a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.url)}</a>`, true)),
    music: () => { window.__music.toggle().then(() => print(`${window.__music.isPlaying() ? 'Playing' : 'Paused'}: ${data.track.title} by ${data.track.artist}`)); },
    projects: () => data.projects.forEach(p => print(`${p.name} [${p.tech.join(', ')}] ${p.desc}`)),
    clear: () => { out.textContent = ''; }
  };
  const open = () => { box.hidden = false; inp.focus(); if (!out.children.length) print('Type "help" to list commands.'); };
  const close = () => { box.hidden = true; };
  addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); box.hidden ? open() : close(); }
    else if (e.key === 'Escape' && !box.hidden) close();
  });
  box.addEventListener('pointerdown', e => { if (e.target === box) close(); });
  inp.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    const v = inp.value.trim().toLowerCase(); inp.value = '';
    if (!v) return;
    print('> ' + v);
    (cmds[v] || (() => print(`Unknown command "${v}". Type "help".`)))();
  });
})();
})();
