import json, os, threading
from flask import Flask, render_template, jsonify

app = Flask(__name__)
BASE = os.path.dirname(os.path.abspath(__file__))
COUNTER = os.path.join(BASE, "views.json")
lock = threading.Lock()

PROFILE = {
    "name": "YOURNAME",
    "status": "Welcome to my profile.",
    "bio": "Building things that feel like the future.",
    "location": "Novi Travnik",
    "tags": ["Developer", "Gamer"],
    "joined": "Jan 2024",
    "socials": [
        {"icon": "fa-brands fa-discord", "ab": "DC", "label": "Discord", "url": "#"},
        {"icon": "fa-brands fa-github", "ab": "GH", "label": "GitHub", "url": "#"},
        {"icon": "fa-brands fa-steam", "ab": "ST", "label": "Steam", "url": "#"},
        {"icon": "fa-brands fa-instagram", "ab": "IG", "label": "Instagram", "url": "#"},
        {"icon": "fa-brands fa-youtube", "ab": "YT", "label": "YouTube", "url": "#"},
    ],
    "badges": [
        {"g": "\u2605", "tip": "Founder"},
        {"g": "</>", "tip": "Developer"},
        {"g": "\u25c8", "tip": "Gamer"},
        {"g": "\u21af", "tip": "Early supporter"},
    ],
    "track": {"title": "Midnight Protocol", "artist": "Unknown Artist"},
    "projects": [
        {"name": "Nightfall API", "desc": "Low-latency REST service with token auth and live metrics.",
         "tech": ["Python", "Flask", "Redis"], "github": "#", "demo": "#"},
        {"name": "Crimson UI", "desc": "A dark glass component kit with zero-dependency animations.",
         "tech": ["CSS", "JavaScript"], "github": "#", "demo": "#"},
        {"name": "Signal Bot", "desc": "Discord companion that tracks presence and match stats.",
         "tech": ["Python", "discord.py"], "github": "#", "demo": "#"},
    ],
}

def read_views():
    try:
        with open(COUNTER) as f:
            return json.load(f)["views"]
    except Exception:
        return 4820

def bump_views():
    with lock:
        v = read_views() + 1
        try:
            with open(COUNTER, "w") as f:
                json.dump({"views": v}, f)
        except OSError:
            pass
        return v

@app.route("/")
def index():
    has_audio = os.path.exists(os.path.join(BASE, "static", "audio", "track.mp3"))
    return render_template("index.html", p=PROFILE, views=bump_views(), has_audio=has_audio,
                           avatar=os.path.exists(os.path.join(BASE, "static", "images", "avatar.jpg")))

@app.route("/api/stats")
def stats():
    return jsonify(projects=len(PROFILE["projects"]), visitors=read_views(), status="ONLINE", uptime="99.9%")

if __name__ == "__main__":
    app.run(debug=True, port=5000)
